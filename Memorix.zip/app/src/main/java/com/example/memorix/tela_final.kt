package com.example.memorix

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class tela_final : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela_final)
    }
}
