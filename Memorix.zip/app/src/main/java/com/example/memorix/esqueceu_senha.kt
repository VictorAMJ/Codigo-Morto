package com.example.memorix

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class esqueceu_senha : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.esqueceu_senha)

        val acesseButton = findViewById<Button>(R.id.button2)
        acesseButton.setOnClickListener {
            val intent = Intent(this, pastas_existentes::class.java)
            startActivity(intent)
            finish()
        }
    }
}
