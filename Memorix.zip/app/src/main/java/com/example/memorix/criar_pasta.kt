package com.example.memorix

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class criar_pasta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.criar_pasta)

        val salvarButton = findViewById<Button>(R.id.salvar)
        salvarButton.setOnClickListener {
            val intent = Intent(this,pastas_existentes::class.java)
            startActivity(intent)
            finish()
        }
    }
}
