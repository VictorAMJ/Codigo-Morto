package com.example.memorix

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class dentro_pasta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dentro_pasta)

        val botaoAdicionar = findViewById<Button>(R.id.buttonAddSenhas)
        botaoAdicionar.setOnClickListener {
            val intent = Intent(this, nova_senha::class.java)
            startActivity(intent)
            finish()
        }



    }
}
