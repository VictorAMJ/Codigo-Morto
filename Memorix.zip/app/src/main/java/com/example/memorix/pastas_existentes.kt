package com.example.memorix

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class pastas_existentes : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pastas_existentes)

        val layoutSenhaEmail = findViewById<LinearLayout>(R.id.layoutSenhaEmail)
        layoutSenhaEmail.setOnClickListener {
            val intent = Intent(this, dentro_pasta::class.java)
            startActivity(intent)
        }

        val addButton = findViewById<Button>(R.id.buttonAddPasta)
        addButton.setOnClickListener {
            val intent = Intent(this, criar_pasta::class.java)
            startActivity(intent)
            finish()
        }
    }
}

